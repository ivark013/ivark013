import cv2
import numpy as np
from django.conf import settings
from django.core.mail import send_mail
import requests
import torch
import yaml
import os

# Global variable to store the YOLO model
YOLO_MODEL = None


def load_yolo_model(model_name):
    global YOLO_MODEL
    if YOLO_MODEL is None:
        try:
            model_path = settings.AI_MODELS[model_name]["model"]
            yaml_path = settings.AI_MODELS[model_name]["yaml"]

            # Clear torch hub cache
            torch.hub.clear_cache()

            # Load YOLO model using PyTorch with force_reload=True
            YOLO_MODEL = torch.hub.load(
                "ultralytics/yolov5", "custom", path=model_path, force_reload=True
            )

            # Load class names from YAML file
            with open(yaml_path, "r") as f:
                yaml_data = yaml.safe_load(f)
                YOLO_MODEL.names = yaml_data["names"]

            # Set model parameters
            YOLO_MODEL.conf = 0.5  # Confidence threshold
            YOLO_MODEL.iou = 0.45  # IOU threshold for NMS

            print("YOLO model loaded successfully")
        except Exception as e:
            print(f"Error loading YOLO model: {str(e)}")
            YOLO_MODEL = None


def detect_objects(image, model_name):
    global YOLO_MODEL
    if YOLO_MODEL is None:
        load_yolo_model(model_name)

    if YOLO_MODEL is None:
        print("YOLO model not available")
        return []

    try:
        # Ensure image is in RGB format
        if len(image.shape) == 2:  # If grayscale
            image = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
        elif image.shape[2] == 4:  # If RGBA
            image = cv2.cvtColor(image, cv2.COLOR_RGBA2RGB)

        # Perform inference
        results = YOLO_MODEL(image)

        # Process detections
        detections = []
        for *xyxy, conf, cls in results.xyxy[0]:
            if conf > YOLO_MODEL.conf:
                label = YOLO_MODEL.names[int(cls)]
                x, y, w, h = xyxy[0], xyxy[1], xyxy[2] - xyxy[0], xyxy[3] - xyxy[1]
                detections.append(
                    (label, float(conf), (int(x), int(y), int(w), int(h)))
                )

        return detections
    except Exception as e:
        print(f"Error in object detection: {str(e)}")
        return []


def send_notification(alert):
    # Send email notification
    if alert.camera.notificationsettings.email_notifications:
        try:
            send_mail(
                "Security Alert",
                f"Alert from camera {alert.camera.name}: {alert.description}",
                settings.EMAIL_HOST_USER,
                [alert.camera.notificationsettings.user.email],
                fail_silently=False,
            )
            print(
                f"Email notification sent to {alert.camera.notificationsettings.user.email}"
            )
        except Exception as e:
            print(f"Error sending email notification: {str(e)}")

    # Send Telegram notification
    if alert.camera.notificationsettings.telegram_notifications:
        try:
            telegram_bot_token = settings.TELEGRAM_BOT_TOKEN
            chat_id = alert.camera.notificationsettings.telegram_chat_id
            message = f"Alert from camera {alert.camera.name}: {alert.description}"
            url = f"https://api.telegram.org/bot{telegram_bot_token}/sendMessage"
            payload = {"chat_id": chat_id, "text": message}
            response = requests.post(url, json=payload)
            if response.status_code == 200:
                print(f"Telegram notification sent to chat ID {chat_id}")
            else:
                print(
                    f"Failed to send Telegram notification. Status code: {response.status_code}"
                )
        except Exception as e:
            print(f"Error sending Telegram notification: {str(e)}")

    # Send WhatsApp notification
    if alert.camera.notificationsettings.whatsapp_notifications:
        try:
            whatsapp_number = alert.camera.notificationsettings.whatsapp_number
            message = f"Alert from camera {alert.camera.name}: {alert.description}"

            # Use the WhatsApp API service to send the message
            # This is a placeholder and needs to be implemented with an actual WhatsApp API service
            whatsapp_api_key = settings.WHATSAPP_API_KEY
            # Example: whatsapp_api.send_message(whatsapp_api_key, whatsapp_number, message)
            print(f"WhatsApp notification sent to {whatsapp_number}: {message}")
        except Exception as e:
            print(f"Error sending WhatsApp notification: {str(e)}")
