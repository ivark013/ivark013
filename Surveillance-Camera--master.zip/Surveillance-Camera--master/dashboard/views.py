import cv2
import numpy as np
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.http import StreamingHttpResponse, HttpResponse, JsonResponse
from django.views.decorators import gzip
from django.conf import settings
from .models import Camera, Alert, NotificationSettings
from .utils import detect_objects, send_notification, load_yolo_model
from django.contrib.auth import logout
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
import threading
import time
import uuid
import os
import json
from django.core.cache import cache
import requests


def get_available_cameras():
    """Get list of available cameras connected to the system."""
    available_cameras = []
    index = 0
    while True:
        cap = cv2.VideoCapture(index)
        if not cap.read()[0]:
            break
        else:
            camera_name = f"كاميرا {index}"
            camera_id = f"camera_{index}"
            available_cameras.append((camera_name, camera_id))
            cap.release()
        index += 1
    return available_cameras


def update_camera_database():
    """Update the database with currently available cameras."""
    available_cameras = get_available_cameras()
    current_camera_ids = set(Camera.objects.values_list("camera_id", flat=True))

    for name, camera_id in available_cameras:
        camera, created = Camera.objects.get_or_create(
            camera_id=camera_id, defaults={"name": name}
        )
        if not created:
            camera.name = name
            camera.is_active = True
            camera.save()
        current_camera_ids.discard(camera_id)

    # Set remaining cameras as inactive
    Camera.objects.filter(camera_id__in=current_camera_ids).update(is_active=False)


class CameraStream:
    def __init__(self, camera_id):
        self.camera = Camera.objects.get(camera_id=camera_id)
        try:
            cam_number = int(camera_id.split("_")[1])

            # محاولة فتح الكاميرا بعدة طرق
            self.video = cv2.VideoCapture(cam_number, cv2.CAP_DSHOW)
            if not self.video.isOpened():
                self.video = cv2.VideoCapture(cam_number)
            if not self.video.isOpened():
                self.video = cv2.VideoCapture(cam_number, cv2.CAP_FFMPEG)

            if not self.video.isOpened():
                raise ValueError(f"فشل في فتح الكاميرا {camera_id}")

            # ضبط خصائص الكاميرا
            self.video.set(cv2.CAP_PROP_FRAME_WIDTH, 280)
            self.video.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
            self.video.set(cv2.CAP_PROP_FPS, 30)

            # قراءة إطار تجريبي
            success, _ = self.video.read()
            if not success:
                raise ValueError("فشل في قراءة الإطار التجريبي")

        except Exception as e:
            print(f"خطأ في تهيئة الكاميرا {camera_id}: {str(e)}")
            raise

    def __del__(self):
        if hasattr(self, "video") and self.video.isOpened():
            self.video.release()

    def get_frame(self):
        if not hasattr(self, "video") or not self.video.isOpened():
            print(f"الكاميرا {self.camera.camera_id} غير مفتوحة.")
            return None

        success, frame = self.video.read()
        if not success:
            print("فشل في قراءة الإطار من الكاميرا.")
            return None

        try:
            # معالجة الإطار
            detections = detect_objects(
                frame, "violence"
            )  # يفترض أن "violence" هو اسم النموذج

            # رسم الاكتشافات
            for label, confidence, (x, y, w, h) in detections:
                cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
                cv2.putText(
                    frame,
                    f"{label} {confidence:.2f}",
                    (x, y - 10),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.9,
                    (0, 255, 0),
                    2,
                )

            # ترميز الإطار
            _, jpeg = cv2.imencode(".jpg", frame)
            return jpeg.tobytes()
        except Exception as e:
            print(f"خطأ أثناء معالجة الإطار: {str(e)}")
            return None


def gen(camera_id):
    """توليد إطارات الكاميرا."""
    stream = CameraStream(camera_id)
    while True:
        frame = stream.get_frame()
        if frame is not None:
            yield (
                b"--frame\r\n" b"Content-Type: image/jpeg\r\n\r\n" + frame + b"\r\n\r\n"
            )
        else:
            print("تم استلام إطار فارغ، محاولة إعادة الاتصال...")
            time.sleep(1)  # انتظار قبل المحاولة مرة أخرى


@gzip.gzip_page
@login_required
def video_feed(request, camera_id):
    """تدفق الفيديو من الكاميرا."""
    try:
        return StreamingHttpResponse(
            gen(camera_id), content_type="multipart/x-mixed-replace;boundary=frame"
        )
    except Exception as e:
        print(f"خطأ في تدفق الفيديو: {str(e)}")
        return HttpResponse(f"خطأ: {str(e)}", status=500)


@login_required
def dashboard(request):
    """Main dashboard view."""
    update_camera_database()
    cameras = Camera.objects.filter(is_active=True)
    alerts = Alert.objects.filter(is_read=False).order_by("-timestamp")[:5]

    # تحميل نموذج YOLO مسبقاً
    load_yolo_model("violence")

    return render(
        request, "dashboard/dashboard.html", {"cameras": cameras, "alerts": alerts}
    )


@login_required
@require_POST
@csrf_exempt
def toggle_camera(request, camera_id):
    """Toggle camera active status."""
    try:
        camera = Camera.objects.get(camera_id=camera_id)
        camera.is_active = not camera.is_active
        camera.save()
        return JsonResponse({"status": camera.is_active})
    except Camera.DoesNotExist:
        return JsonResponse({"error": "الكاميرا غير موجودة"}, status=404)
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)


@login_required
def alerts(request):
    """View all alerts."""
    alerts = Alert.objects.all().order_by("-timestamp")
    return render(request, "dashboard/alerts.html", {"alerts": alerts})


@login_required
@require_POST
def mark_alert_read(request, alert_id):
    """Mark an alert as read."""
    try:
        alert = Alert.objects.get(id=alert_id)
        alert.is_read = True
        alert.save()
        return JsonResponse({"success": True})
    except Alert.DoesNotExist:
        return JsonResponse({"error": "التنبيه غير موجود"}, status=404)
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)


@login_required
def notification_settings(request):
    """View and update notification settings."""
    settings, created = NotificationSettings.objects.get_or_create(user=request.user)
    if request.method == "POST":
        try:
            settings.email_notifications = "email_notifications" in request.POST
            settings.telegram_notifications = "telegram_notifications" in request.POST
            settings.whatsapp_notifications = "whatsapp_notifications" in request.POST
            settings.telegram_chat_id = request.POST.get("telegram_chat_id", "")
            settings.whatsapp_number = request.POST.get("whatsapp_number", "")
            settings.save()
            return redirect("dashboard")
        except Exception as e:
            print(f"Error saving notification settings: {str(e)}")
            return render(
                request,
                "dashboard/notification_settings.html",
                {"settings": settings, "error": "حدث خطأ أثناء حفظ الإعدادات"},
            )
    return render(
        request, "dashboard/notification_settings.html", {"settings": settings}
    )


@login_required
def get_latest_alerts(request):
    """Get latest unread alerts."""
    cache_key = f"latest_alerts_{request.user.id}"
    cached_alerts = cache.get(cache_key)

    if cached_alerts is None:
        alerts = Alert.objects.filter(is_read=False).order_by("-timestamp")[:5]
        alerts_data = [
            {
                "camera_name": alert.camera.name,
                "description": alert.description,
                "timestamp": alert.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
            }
            for alert in alerts
        ]
        cache.set(cache_key, alerts_data, 60)  # Cache for 60 seconds
        return JsonResponse({"alerts": alerts_data})

    return JsonResponse({"alerts": cached_alerts})


@login_required
@require_POST
@csrf_exempt
def update_notification_settings(request):
    """Update notification settings via AJAX."""
    try:
        data = json.loads(request.body)
        settings, created = NotificationSettings.objects.get_or_create(
            user=request.user
        )

        settings.email_notifications = data.get("emailNotifications", False)
        settings.telegram_notifications = data.get("telegramNotifications", False)
        settings.whatsapp_notifications = data.get("whatsappNotifications", False)
        settings.telegram_chat_id = data.get("telegramUsername", "")
        settings.whatsapp_number = data.get("whatsappNumber", "")

        settings.save()
        return JsonResponse({"success": True})
    except Exception as e:
        print(f"Error updating notification settings: {str(e)}")
        return JsonResponse({"success": False, "error": str(e)})


@login_required
def get_cameras(request):
    """Get list of active cameras."""
    try:
        cameras = Camera.objects.filter(is_active=True)
        camera_data = [
            {
                "id": camera.id,
                "name": camera.name,
                "camera_id": camera.camera_id,
                "is_active": camera.is_active,
            }
            for camera in cameras
        ]
        return JsonResponse({"cameras": camera_data})
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)


@login_required
def get_alerts(request):
    """Get recent alerts."""
    try:
        alerts = Alert.objects.all().order_by("-timestamp")[:10]
        alert_data = [
            {
                "id": alert.id,
                "camera_name": alert.camera.name,
                "description": alert.description,
                "timestamp": alert.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
                "is_read": alert.is_read,
                "severity": alert.severity,
            }
            for alert in alerts
        ]
        return JsonResponse({"alerts": alert_data})
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)


@login_required
def get_notification_settings(request):
    """Get current notification settings."""
    try:
        settings, created = NotificationSettings.objects.get_or_create(
            user=request.user
        )
        return JsonResponse(
            {
                "emailNotifications": settings.email_notifications,
                "telegramNotifications": settings.telegram_notifications,
                "whatsappNotifications": settings.whatsapp_notifications,
                "telegramUsername": settings.telegram_chat_id,
                "whatsappNumber": settings.whatsapp_number,
            }
        )
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)


@login_required
@require_POST
def custom_logout(request):
    """Logout user."""
    logout(request)
    return redirect("login")


@csrf_exempt
@require_POST
def chatbot(request):
    message = request.POST.get("message")
    if not message:
        return JsonResponse({"error": "No message provided"}, status=400)

    # استبدل هذا برابط API الشات بوت الخاص بك
    chatbot_api_url = "https://your-chatbot-api-url.com/chat"

    try:
        response = requests.post(chatbot_api_url, json={"message": message})
        response.raise_for_status()
        chatbot_response = response.json()
        return JsonResponse(chatbot_response)
    except requests.RequestException as e:
        return JsonResponse({"error": str(e)}, status=500)
